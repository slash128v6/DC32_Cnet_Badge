# Decoding a WAV file

In this example we decode a WAV file into RAW output and send it to the Serial output. 

This example uses the preferred EncodedAudioStream class. 

Complie with Partition Scheme Huge APP!