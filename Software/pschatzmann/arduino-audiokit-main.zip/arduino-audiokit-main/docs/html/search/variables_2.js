var searchData=
[
  ['codec_5fmode_90',['codec_mode',['../structaudiokit_1_1_audio_kit_config.html#aa4a282bcac569e288fc6c779f486fa02',1,'audiokit::AudioKitConfig']]]
];
