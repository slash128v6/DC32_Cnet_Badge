var searchData=
[
  ['begin_8',['begin',['../classaudiokit_1_1_audio_kit.html#a5112da6adf0e8b9b73bfadc293ff2a11',1,'audiokit::AudioKit']]],
  ['bits_5fper_5fsample_9',['bits_per_sample',['../structaudiokit_1_1_audio_kit_config.html#a30463f7640a293b8958b026638932a79',1,'audiokit::AudioKitConfig']]],
  ['bitspersample_10',['bitsPerSample',['../structaudiokit_1_1_audio_kit_config.html#aaaef96c0f87b147eda7542638fbcdc36',1,'audiokit::AudioKitConfig']]],
  ['board_5fdriver_11',['board_driver',['../classboard__driver.html',1,'']]]
];
