var searchData=
[
  ['volume_204',['volume',['../class_audio_kit.html#a7d8fe8f564faf19535f9686aa23ed414',1,'AudioKit']]]
];
