var searchData=
[
  ['audio_5fkit_5fpins_49',['audio_kit_pins',['../audiokit__board_8h.html#structaudio__kit__pins',1,'']]],
  ['audiokit_50',['AudioKit',['../classaudiokit_1_1_audio_kit.html',1,'audiokit']]],
  ['audiokitconfig_51',['AudioKitConfig',['../structaudiokit_1_1_audio_kit_config.html',1,'audiokit']]]
];
