var searchData=
[
  ['bits_5fper_5fsample_89',['bits_per_sample',['../structaudiokit_1_1_audio_kit_config.html#a30463f7640a293b8958b026638932a79',1,'audiokit::AudioKitConfig']]]
];
