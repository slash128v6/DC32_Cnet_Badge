var searchData=
[
  ['sample_5frate_96',['sample_rate',['../structaudiokit_1_1_audio_kit_config.html#a759b923cb717693d467aba263e133937',1,'audiokit::AudioKitConfig']]]
];
