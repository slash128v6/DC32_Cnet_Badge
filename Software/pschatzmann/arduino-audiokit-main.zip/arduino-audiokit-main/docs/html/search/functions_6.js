var searchData=
[
  ['ismaster_62',['isMaster',['../structaudiokit_1_1_audio_kit_config.html#a018ab3bced66bae029b95c2d7d76bf65',1,'audiokit::AudioKitConfig']]],
  ['issdactive_63',['isSDActive',['../classaudiokit_1_1_audio_kit.html#a0aeafeea501ef458eeb8ba53470aebbb',1,'audiokit::AudioKit']]]
];
