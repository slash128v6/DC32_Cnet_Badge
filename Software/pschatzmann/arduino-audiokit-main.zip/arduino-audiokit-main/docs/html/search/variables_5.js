var searchData=
[
  ['master_5fslave_5fmode_94',['master_slave_mode',['../structaudiokit_1_1_audio_kit_config.html#a62a2e936c9cd587494c35decf55b7386',1,'audiokit::AudioKitConfig']]]
];
