var searchData=
[
  ['i2c_5fmode_5fmaster_397',['I2C_MODE_MASTER',['../audio__gpio_8h.html#ac1e2996ebee909590af8e3cc1c316c25a166443f9a57684d8e4970f28a7acf982',1,'audio_gpio.h']]],
  ['i2c_5fmode_5fslave_398',['I2C_MODE_SLAVE',['../audio__gpio_8h.html#ac1e2996ebee909590af8e3cc1c316c25a10a3fafafb52ab45984aa5d5a17171a0',1,'audio_gpio.h']]]
];
