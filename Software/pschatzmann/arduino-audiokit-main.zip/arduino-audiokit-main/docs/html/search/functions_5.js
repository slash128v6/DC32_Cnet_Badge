var searchData=
[
  ['headphonestatus_61',['headphoneStatus',['../classaudiokit_1_1_audio_kit.html#a322effdd6fa1cb61095a0483e2aa87cd',1,'audiokit::AudioKit']]]
];
