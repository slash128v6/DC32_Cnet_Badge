var searchData=
[
  ['pinadcdetect_64',['pinAdcDetect',['../classaudiokit_1_1_audio_kit.html#ae9b1362264b11067e53e139b81e86cff',1,'audiokit::AudioKit']]],
  ['pinauxin_65',['pinAuxin',['../classaudiokit_1_1_audio_kit.html#a24c9a16fb268085127f3f3f60cbf01d5',1,'audiokit::AudioKit']]],
  ['pinblueled_66',['pinBlueLed',['../classaudiokit_1_1_audio_kit.html#a7e85c1c04ad8941180f63205ab0b57a5',1,'audiokit::AudioKit']]],
  ['pines7243mclk_67',['pinEs7243Mclk',['../classaudiokit_1_1_audio_kit.html#ad6ab9544898fc5716645c49948f48785',1,'audiokit::AudioKit']]],
  ['pingreenled_68',['pinGreenLed',['../classaudiokit_1_1_audio_kit.html#a8aac0651779e1613055c7addbda88f9b',1,'audiokit::AudioKit']]],
  ['pinheadphonedetect_69',['pinHeadphoneDetect',['../classaudiokit_1_1_audio_kit.html#a946cf23854985e1dea5aa23fd1b5acd9',1,'audiokit::AudioKit']]],
  ['pininputmode_70',['pinInputMode',['../classaudiokit_1_1_audio_kit.html#a204896f3127128cbe1f69b70eefd4d72',1,'audiokit::AudioKit']]],
  ['pininputplay_71',['pinInputPlay',['../classaudiokit_1_1_audio_kit.html#ab2430362114458eb2edb7867f9dbfac4',1,'audiokit::AudioKit']]],
  ['pininputrec_72',['pinInputRec',['../classaudiokit_1_1_audio_kit.html#aa6f799bab8eefa0b8f24bb42f68c8b87',1,'audiokit::AudioKit']]],
  ['pininputset_73',['pinInputSet',['../classaudiokit_1_1_audio_kit.html#a6532bcf8248e8a094e6ae98e4b6de439',1,'audiokit::AudioKit']]],
  ['pinpaenable_74',['pinPaEnable',['../classaudiokit_1_1_audio_kit.html#a04928dc7c1aaf7f6264db584ad87c09f',1,'audiokit::AudioKit']]],
  ['pinresetboard_75',['pinResetBoard',['../classaudiokit_1_1_audio_kit.html#aa756e62f1535091a9d06b3bb7f5bb318',1,'audiokit::AudioKit']]],
  ['pinresetcodec_76',['pinResetCodec',['../classaudiokit_1_1_audio_kit.html#a20fc1c9ebbca39b6238f1411890639b8',1,'audiokit::AudioKit']]],
  ['pinvolumedown_77',['pinVolumeDown',['../classaudiokit_1_1_audio_kit.html#ac707c4200dad4bc961c66813ac88aa56',1,'audiokit::AudioKit']]],
  ['pinvolumeup_78',['pinVolumeUp',['../classaudiokit_1_1_audio_kit.html#a3ea17670868fc7ac3691162a12f7c153',1,'audiokit::AudioKit']]]
];
