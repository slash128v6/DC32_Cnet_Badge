var searchData=
[
  ['sample_5frate_293',['sample_rate',['../struct_audio_kit_config.html#adefddc85df8f2a25c605ce58b6dde31a',1,'AudioKitConfig']]],
  ['samples_294',['samples',['../audio__hal_8h.html#a2150600c54d6c38a3360d96583991084',1,'audio_hal_codec_i2s_iface_t']]],
  ['scl_5fio_5fnum_295',['scl_io_num',['../audio__gpio_8h.html#ada27de59d612ca9b8a1113ca6fe880ec',1,'i2c_config_t']]],
  ['scl_5fpullup_5fen_296',['scl_pullup_en',['../audio__gpio_8h.html#aa34aad87ac08d75c13d9307c48815baa',1,'i2c_config_t']]],
  ['sclk_5fdiv_297',['sclk_div',['../structes__i2s__clock__t.html#aff86f7381a0c1372602e7e6c61476854',1,'es_i2s_clock_t']]],
  ['sclk_5fio_5fnum_298',['sclk_io_num',['../audio__gpio_8h.html#a5367bdffef8b20cb7158053f3ee2ee3b',1,'spi_bus_config_t']]],
  ['sda_5fio_5fnum_299',['sda_io_num',['../audio__gpio_8h.html#a8aff6814eaf383442b05cb2a07b3e90d',1,'i2c_config_t']]],
  ['sda_5fpullup_5fen_300',['sda_pullup_en',['../audio__gpio_8h.html#a97b18b2329ef69ff7ea2b7cd2cd09801',1,'i2c_config_t']]],
  ['spics_5fio_5fnum_301',['spics_io_num',['../audio__gpio_8h.html#a125057d318b9467a5dd3f1b8a72342f6',1,'spi_device_interface_config_t']]]
];
