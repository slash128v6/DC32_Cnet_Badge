var searchData=
[
  ['dac_5foutput_91',['dac_output',['../structaudiokit_1_1_audio_kit_config.html#a9dd9f607f10f3e7f6cdb9121639ba452',1,'audiokit::AudioKitConfig']]],
  ['driver_92',['driver',['../structaudiokit_1_1_audio_kit_config.html#a23847eaad7a8582ef6895c5d444a7f9a',1,'audiokit::AudioKitConfig']]]
];
