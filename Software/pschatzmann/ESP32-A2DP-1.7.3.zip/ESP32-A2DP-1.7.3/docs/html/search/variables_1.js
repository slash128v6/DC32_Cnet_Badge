var searchData=
[
  ['event_0',['event',['../structapp__msg__t.html#a94101fa8211369ac8234e5052922bf1d',1,'app_msg_t']]]
];
